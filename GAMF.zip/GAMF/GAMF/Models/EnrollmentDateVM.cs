﻿namespace GAMF.Models
{
    public class EnrollmentDateVM
    {
        public DateTimeOffset EnrollmentDate { get; set; }
        public int StudentCount { get; set; }

    }
}
