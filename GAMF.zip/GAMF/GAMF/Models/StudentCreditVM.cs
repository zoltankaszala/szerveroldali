﻿namespace GAMF.Models
{
    public class StudentCreditVM
    {
        public string StudentName { get; set; }
        public int CreditSum { get; set; }
    }
}
