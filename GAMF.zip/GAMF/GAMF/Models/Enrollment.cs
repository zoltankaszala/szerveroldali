﻿using System.ComponentModel.DataAnnotations;
using System.Xml.Linq;

namespace GAMF.Models
{
    public enum Grade {A, B, C, D, F }  //osztályzatok
    public class Enrollment
    {
        public int EnrollmentId { get; set; }
        public int CourseId { get; set; }
        public int StudentId { get; set; }

        [Display(Name = "Érdemjegy")]
        public Grade? Grade { get; set; }   //nullable is lehet
        public virtual Course Course { get; set; } //navigation property
        public virtual Student Student { get; set; } //navigation property
    }
}
